#  __     __   __  __ ____ ____   __       ___ ____ ____
# (  )   /__\ (  \/  (  _ (  _ \ /__\     / __(_  _(_  _)
#  )(__ /(__)\ )    ( ) _ <)(_) /(__)\   ( (_-._)(_  )(
# (____(__)(__(_/\/\_(____(____(__)(__)   \___(____)(__)

__title__ = 'lambda-git'
__description__ = 'A package to install git in AWS Lambda.'
__url__ = 'https://github.com/eredi93/lambda-git'
__version__ = '0.1.1'
__author__ = 'Jacopo Scrinzi'
__author_email__ = 'scrinzi.jacopo@gmail.com'
__license__ = 'MIT'
