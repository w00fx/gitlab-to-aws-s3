from __future__ import absolute_import
import logging

logging.basicConfig()
LOGGER = logging.getLogger('git')
LOGGER.setLevel(logging.INFO)
