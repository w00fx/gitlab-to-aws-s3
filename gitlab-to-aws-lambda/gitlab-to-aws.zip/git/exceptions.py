class GitExecutionError(Exception):
    pass
